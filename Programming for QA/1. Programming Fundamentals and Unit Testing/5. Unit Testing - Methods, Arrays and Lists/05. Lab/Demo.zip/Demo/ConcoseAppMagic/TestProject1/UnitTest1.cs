namespace TestProject1
{
    public class Tests
    {
        [SetUp]
        public void Setup()
        {
        }

        [Test]
        public void Test1()
        {
            int sum = Program.Sum(10, 20);
            Assert.Pass();
        }
    }
}