﻿namespace ConsoleAppMagic
{
    public class Program
    {
        static void Main(string[] args)
        {
            Console.WriteLine();
        }

        public static int Sum(int a, int b)
        {
            return a + b;
        }
    }
}