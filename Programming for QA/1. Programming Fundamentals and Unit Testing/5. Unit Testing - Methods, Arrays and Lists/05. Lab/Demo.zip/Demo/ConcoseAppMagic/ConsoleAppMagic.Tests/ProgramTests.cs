using NUnit.Framework;

namespace ConsoleAppMagic.Tests
{
    public class ProgramTests
    {
        [Test]
        public void Test_WhenSumIsGivenTwoParams_ShouldReturnCurrentSum()
        {
            int sum = Program.Sum(10, 20);
            Assert.AreEqual(30, sum);
        }

        [Test]
        public void Test_WhenSumIsGivenTwoParams_ShouldReturnCurrentSum2()
        {
            int sum = Program.Sum(20, 20);
            Assert.AreEqual(40, sum);
        }
    }
}