﻿using NUnit.Framework;

using System.Collections.Generic;

namespace TestApp.UnitTests;

public class NumberProcessorTests
{
    [Test]
    public void Test_ProcessNumbers_SquareEvenNumbers()
    {
        // Arrange
        List<int> input = new() { 2, 4, 6 };
        List<double> expected = new() { 4, 16, 36 };

        // Act
        List<double> actual = NumberProcessor.ProcessNumbers(input);

        // Assert
        CollectionAssert.AreEqual(expected, actual, Comparer<double>.Default);
    }

    // TODO: finish test
    [Test]
    public void Test_ProcessNumbers_SquareRootOddNumbers()
    {
        // Arrange

        // Act
        
        // Assert
        //CollectionAssert.AreEqual(expected, actual, Comparer<double>.Default);
    }

    // TODO: finish test
    [Test]
    public void Test_ProcessNumbers_HandleZero()
    {
        // Arrange
        List<int> input = new() { 0 };
        List<int> expected = new() { 0 };

        // Act

        // Assert
    }

    [Test]
    public void Test_ProcessNumbers_HandleNegativeNumbers()
    {
        // TODO: finish test
    }

    [Test]
    public void Test_ProcessNumbers_EmptyInput()
    {
        // TODO: finish test
    }
}
