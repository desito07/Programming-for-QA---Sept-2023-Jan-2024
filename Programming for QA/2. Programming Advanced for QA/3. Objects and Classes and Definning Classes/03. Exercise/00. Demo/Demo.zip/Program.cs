﻿using Demo;

Person person = new Person();

person.Name = "Desi";
Console.WriteLine(person.Name);

person.Age = 41;
Console.WriteLine(person.Age);

person.Egn = "8204191437";
Console.WriteLine(person.Egn);
